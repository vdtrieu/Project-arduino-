﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using System.Globalization;
using System.Collections.Specialized;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using BruTile.Web;

namespace firstweb
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private SqlConnection connection;
        private void connectsql()
        {
            string constr = @"Server=tproject.c6y4qzqhktxl.us-west-2.rds.amazonaws.com,1433;User Id=sa;Password=Dark1234;";
            connection = new SqlConnection(constr);
        }
        private bool checktable(string date)
        {
            var todo = string.Format("USE tproject select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME='{0}'", "sample-" + date);
            object result;
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                result = command.ExecuteScalar();
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            if (result != null)
                return true;
            else
                return false;
        }
        private bool createtable(string date)
        {
            var todo = string.Format(@"USE tproject CREATE TABLE [dbo].[{0}](
					[Time] [time](0) NOT NULL,
					[Coor] [nchar](100) NULL,
					[Temperature] [nchar](100) NOT NULL) ON [PRIMARY]", "sample-" + date);
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return true;
        }
        private bool writesample(string date, string time, string coor, string temp)
        {
            var todo = string.Format("USE tproject INSERT INTO dbo.[{0}] ([Time],[Coor],[Temperature]) VALUES ('{1}','{2}','{3}')", "sample-" + date, time, coor, temp);
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                command.ExecuteNonQuery();
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return true;
        }
        private bool createlog()
        {
            var todo = string.Format("USE tproject select * from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME='{0}'", "log");
            var tocreate = string.Format(@"USE tproject CREATE TABLE [dbo].[{0}](
					[DT][nchar](100) NULL) ON [PRIMARY]", "log");
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                if (command.ExecuteScalar() != null)
                    return true;
                else
                {
                    command = new SqlCommand(tocreate, connection);
                    command.ExecuteNonQuery();
                    return true;
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return true;
        }
        private bool writelog(string dt)
        {
            var todo = string.Format("USE tproject select * from dbo.log", "log");
            var tocreate = string.Format("USE tproject INSERT INTO dbo.log([DT]) VALUES ('{0}')", dt);
            var tochange = string.Format(@"USE tproject UPDATE [dbo].log SET [DT] = '{0}'", dt);
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                if (command.ExecuteScalar() != null)
                {
                    command = new SqlCommand(tochange, connection);
                    command.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    command = new SqlCommand(tocreate, connection);
                    command.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                connection.Close();
            }
            return true;
        }
        private string readlog()
        {
            var todo = string.Format("USE tproject select * from dbo.log", "log");
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(todo, connection);
                var result = command.ExecuteScalar();
                if (result != null)
                {
                    return result.ToString().Trim();
                }
                else
                {
                    return string.Empty;
                }
            }
            catch
            {
                return string.Empty;
            }
            finally
            {
                connection.Close();
            }
        }
        private void showmsg(string msg)
        {
            Response.Write(string.Format("<script>alert('{0}')</script>",msg));
        }
        private int listboxsel = 0;
        private List<string> sortdate(List<string> list)
        {
            List<string> newlist = new List<string>();
            int count = list.Count;
            while (count > 0) 
            {
                var max = DateTime.ParseExact(list[0], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                //var max = Convert.ToDateTime(list[0], System.Globalization.CultureInfo.CreateSpecificCulture("en-US"));
                int maxindex = 0;
                for (int j = 0; j < count; j++)
                {
                    var second = DateTime.ParseExact(list[j], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    //var second = Convert.ToDateTime(list[j], System.Globalization.CultureInfo.CreateSpecificCulture("en-US"));
                    if (second > max)
                    {
                        maxindex = j;
                        max = second;
                    }
                }
                list.RemoveAt(maxindex);
                count -= 1;
                newlist.Add(max.ToString("dd-MM-yyyy"));
            }
            return newlist;
        }
        public string lastcoor = string.Empty;
        private void firstload()
        {
            TextBox2.Text = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
            TextBox6.Text = readlog();
            if (string.IsNullOrEmpty(TextBox6.Text))
                return;
            var date = TextBox6.Text.Split(' ')[0];
            string current = string.Format("USE tproject SELECT count(*) from dbo.[{0}]", "sample-" + date);
            string workingday = "USE tproject SELECT count(*) from INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' and TABLE_NAME like 'sample-%'";
            string samplecount = "USE tproject SELECT I.row_count AS [ROWCOUNT] FROM sys.tables AS T INNER JOIN sys.dm_db_partition_stats AS I ON T.object_id = I.object_id AND I.index_id < 2";
            string bindtable = string.Format("USE tproject SELECT * from dbo.[{0}] ORDER BY Time DESC", "sample-" + date);
            string listtable = "USE tproject SELECT TABLE_NAME from INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' and TABLE_NAME like 'sample-%'";
            try
            {
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                ////
                var command = new SqlCommand();

                if (Page.IsPostBack)
                {
                    bindtable = string.Format("USE tproject SELECT * from dbo.[{0}] ORDER BY Time DESC", "sample-" + ListBox1.SelectedValue.ToString());
                    listboxsel = ListBox1.SelectedIndex;
                    ListBox1.Items.Clear();
                }
                command = new SqlCommand(bindtable, connection);
                var adapt = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapt.Fill(table);
                lastcoor = table.Rows[0][1].ToString();
                GridView1.DataSource = table;
                GridView1.DataBind();
                ////
                command = new SqlCommand(listtable, connection);
                var list = command.ExecuteReader();
                var listdate = new List<string>();
                while (list.Read())
                {
                    var value = list.GetValue(0).ToString().Trim();
                    listdate.Add(value.Substring(7, value.Length - 7).Replace("-","/"));
                }
                list.Close();
                foreach (string item in sortdate(listdate))
                {
                    ListBox1.Items.Add(item);
                }
                ListBox1.SelectedIndex = listboxsel;
                ////
                command = new SqlCommand(current, connection);
                var result = command.ExecuteScalar();
                if (result != null)
                {
                    TextBox4.Text = result.ToString();
                }
                command = new SqlCommand(workingday, connection);
                var result2 = command.ExecuteScalar();
                if (result != null)
                {
                    TextBox14.Text = result2.ToString();
                }
                command = new SqlCommand(samplecount, connection);
                var result3 = command.ExecuteReader();
                int sum = 0;
                while (result3.Read())
                {
                    sum += Convert.ToInt32(result3.GetValue(0).ToString().Trim());
                }
                TextBox16.Text = (sum-1).ToString();
                ///
                searchmap();
                ///
                ListBox1.Focus();
            }
            catch (Exception e)
            {
                showmsg(e.Message);
                return;
            }
            finally
            {
                connection.Close();
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            Page.MaintainScrollPositionOnPostBack = true;
            connectsql();
            if (!createlog())
            {
                showmsg("Error creating log");
                return;
            }
            if (Request.Params["temperature"] != null)
            {
                string temperature = Request.Params["temperature"];
                string coor = string.Empty;
                if (Request.Params["coor"] != null)
                    coor = Request.Params["coor"];
                string date = DateTime.Now.ToString("dd-MM-yyyy");
                if (!checktable(date))
                    if (!createtable(date))
                        Response.End(); ;
                string time = DateTime.Now.ToString("HH:mm:ss");
                if (!writesample(date, time, coor, temperature))
                    Response.End(); ;
                string lastupdate = date + " " + time;
                if (!writelog(lastupdate))
                    showmsg("Updated. Error writting log");
                Response.Write("Success");
                Response.End();
            }
            firstload();
            drawchart(); 
        }
        private void avghour()
        {
            xseri = new List<string>();
            yseri = new List<double>();
            int count = 0;
            miny = 100000;
            maxy = -100000;
            for (int i = 0; i < 24; i++)
            {
                string hour = i.ToString();
                if (hour.Length == 1)
                    hour = "0" + hour;
                xseri.Add(string.Format("{0}:00", hour));
                hour += "%";
                string todo = string.Format("USE tproject SELECT AVG(CONVERT(float,[Temperature])) FROM[dbo].[{0}] WHERE[Time] like '{1}'", "sample-" + ListBox1.SelectedValue.ToString(), hour);
                try
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                        connection.Open();
                    var command = new SqlCommand(todo, connection);
                    var result = command.ExecuteScalar();
                    if (result != null && !string.IsNullOrEmpty(result.ToString().Trim()))
                    {
                        if (result.ToString().Trim() != "NULL")
                        {
                            yseri.Add(Math.Round(Convert.ToDouble(result.ToString().Trim()),2));
                            if (Convert.ToDouble(result.ToString().Trim()) < miny)
                                miny = Convert.ToDouble(result.ToString().Trim());
                            if (Convert.ToDouble(result.ToString().Trim()) > maxy)
                                maxy = Convert.ToDouble(result.ToString().Trim());
                        }
                    }
                    else
                    {
                        yseri.Add(0);
                        miny = 0;
                    }
                }
                catch
                {
                    yseri.Add(0);
                }
                finally
                {
                    connection.Close();
                }
            }
        }
        private void nsample(int n)
        {
            xseri = new List<string>();
            yseri = new List<double>();
            int count = 0;
            miny = 100000;
            maxy = -100000;
            var getsample = new List<string>();
            int begin = n;
            if (GridView1.Rows.Count < n && GridView1.Rows.Count > 0)
                begin = GridView1.Rows.Count;
            begin -= 1;
            for (int i = begin; i >=0; i--)
            {
                count += 1;
                xseri.Add(GridView1.Rows[i].Cells[0].Text);
                yseri.Add(Convert.ToDouble(GridView1.Rows[i].Cells[2].Text));
                if (Convert.ToDouble(GridView1.Rows[i].Cells[2].Text) < miny)
                    miny = Convert.ToDouble(GridView1.Rows[i].Cells[2].Text);
                if (Convert.ToDouble(GridView1.Rows[i].Cells[2].Text) > maxy)
                    maxy = Convert.ToDouble(GridView1.Rows[i].Cells[2].Text);
                if (count >= n)
                    break;
            }
            return;
        }
        private List<double> yseri;
        private List<string> xseri;
        private double miny, maxy;
        private void drawchart()
        {
            if (RadioButtonList1.SelectedIndex==0)
                nsample(40);
            else
                avghour();
            Chart1.Series[0].Points.DataBindXY(xseri, yseri);
            Chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Column;
            Chart1.Series[0]["PixelPointWidth"] = "15";
            Chart1.Series[0].ChartType = System.Web.UI.DataVisualization.Charting.SeriesChartType.Line;
            Chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            Chart1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;
            Chart1.ChartAreas[0].AxisX.LabelStyle.Angle = -50;
            Chart1.ChartAreas[0].AxisX.Minimum = 0;
            Chart1.ChartAreas[0].AxisX.Interval = 1;
            Chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
            Chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
            Chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = true;
            Chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = ColorTranslator.FromHtml("#e5e5e5");
            Chart1.Series[0].IsValueShownAsLabel = true;
            Chart1.ChartAreas[0].AxisY.Title = "Temperature";
            Chart1.ChartAreas[0].AxisX.Title = "Time";
            Chart1.ChartAreas[0].AxisY.Maximum = maxy+1;
            Chart1.ChartAreas[0].AxisY.Minimum = miny-1;
            Chart1.ChartAreas[0].RecalculateAxesScale();
            Chart1.ChartAreas[0].AxisX.LineWidth = 0;
            var title = Chart1.Titles.Add("Temperature Statistic");
            title.Font = new System.Drawing.Font("Arial", 15, FontStyle.Regular);
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string url = string.Format("http://{0}/WebForm2.aspx?Name={1}&Age={2}", Request.Url.Authority.ToString(), "123", "123");
            //var req = new HttpClient();
            //var result = req.GetAsync(url).Result;
            //if (result.IsSuccessStatusCode)
            //    DIV1.InnerText = result.Content.ReadAsStringAsync().Result.ToString();
            //iframe1.Src = url;
           
        }
        public bool AcceptAllCertifications(object sender, System.Security.Cryptography.X509Certificates.X509Certificate certification, System.Security.Cryptography.X509Certificates.X509Chain chain, System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            return true;
        }
        protected void tryalert_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", "alert('Member Registered Sucessfully');", true);

        }
        protected void sendsms2_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterClientScriptBlock(this, typeof(Page), "anything", "alert('Data Saved Sucessfully');", true);
        }
        protected void sendsms_Click(object sender, EventArgs e)
        {
            string sendto = "84973472507";
            string senddata = "Nexmo";
            string apikey = "2bee8f58";
            string apisec = "IctlkdlDZtqX0Qqh";
            Uri url = new Uri(string.Format("https://rest.nexmo.com/sms/json?text={0}&from=k&to={1}&api_key={2}&api_secret={3}", senddata, sendto, apikey, apisec));
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebRequest webRequest = WebRequest.Create(url);
            try
            {
                WebResponse webResponse = webRequest.GetResponse();
                string result = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();
                Regex reg = new Regex("remaining-balance\": \"[^\"]+");
                if (reg.Match(result).Success)
                {
                    result = reg.Match(result).Value;
                    result = result.Replace("remaining-balance\": \"", "");
                }
                else
                    throw new Exception();
                string remain = result;
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", string.Format("alert('{0}');", string.Format("Sent. Remain : {0}", remain)), true);
            }
            catch
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", string.Format("alert('{0}');", "Error"), true);
            }
        }
        private string grepjson(string keyword, string source)
        {
            string grap = string.Empty;
            Regex reg = new Regex(string.Format("{0}\":\"[^\"]+", keyword));
            if (reg.Match(source).Success)
            {
                grap = reg.Match(source).Value;
                grap = grap.Replace(string.Format("{0}\":\"", keyword), "");
            }
            return grap;
        }
        private void searchmap()
        {
            if (string.IsNullOrEmpty(lastcoor))
                return;
            string y = lastcoor.Split(',')[0].Trim();
            string x = lastcoor.Split(',')[1].Trim();
            Uri url = new Uri(string.Format("https://api.opencagedata.com/geocode/v1/json?q={0}+{1}&key=f45c7df0378b424898862b3f1663b861", x, y));
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            WebRequest webRequest = WebRequest.Create(url);
            try
            {
                WebResponse webResponse = webRequest.GetResponse();
                string result = new StreamReader(webResponse.GetResponseStream()).ReadToEnd();
                string country = grepjson("country", result);
                string city = grepjson("city", result);
                string building = grepjson("building", result);
                string road = grepjson("road", result);               
                string print = string.Format("{0}, {1}, {2}, {3}", building, road, city, country);
                while ((print[0] == ' ' || print[0] == ',') && print.Length > 1) 
                    print = print.Substring(1);
                print = Regex.Unescape(print);
                coorid.Text = string.Format("Last Coordination : {0}", lastcoor.Trim());
                coordesc.Text = string.Format("Description : {0}", print);
                string src = string.Format("https://www.openstreetmap.org/export/embed.html?bbox={0}%2C{1}&marker={1}%2C{0}", y, x);
                iframemap.Attributes.Remove("src");
                iframemap.Attributes.Add("src", src);
            }
            catch (Exception e)
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", string.Format("alert('{0}');", "Error Getting Map"), true);
            }
        }
        protected void seecoor_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(coorin.Text))
                return;
            string savecoor = lastcoor;
            try
            {
                lastcoor = coorin.Text.ToString();
                searchmap();
                coorid.Text = coorid.Text.Replace("Last Coordination", "Input Coordination");
            }
            catch
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", string.Format("alert('{0}');", "Error Searching"), true);
            }
            finally
            {
                lastcoor = savecoor;
            }
        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
        }
        private void binddate(string date)
        {
            try
            {
                string bindtable = string.Format("USE tproject SELECT * from dbo.[{0}]", "sample-" + date);
                if (connection.State == System.Data.ConnectionState.Closed)
                    connection.Open();
                var command = new SqlCommand(bindtable, connection);
                var adapt = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapt.Fill(table);
                GridView1.DataSource = null;
                GridView1.DataSource = table;
                GridView1.DataBind();
                
                
            }
            catch
            {
                return;
            }
            finally
            {
                connection.Close();
            }
        }
        protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListBox1.SelectedIndex == listboxsel)
            {
                return;
            }
            if (ListBox1.SelectedIndex >= 0)
            {
                binddate(ListBox1.SelectedValue.ToString());
                drawchart();
            }
        }

        protected void Button1_Click2(object sender, EventArgs e)
        {

            
        }
        protected void Timer1_Tick(object sender, EventArgs e)
        {

            //Page.RegisterClientScriptBlock("trys", @"
            //<%=<script language=javascript> function trys() { alert('123'); }</script>");
            //TextBox2.Attributes["onclick"] = "trys()";

        }
    }
}